# داشبورد عملکرد تیم فناوری اطلاعات — Android WebView

این نسخه، داشبورد HTML فعلی را مستقیماً داخل Android WebView قرار می‌دهد و برای ساخت APK از Gradle و GitHub Actions استفاده می‌کند.

## GitHub Actions

فایل `.github/workflows/build-apk.yml` با Java 21 و Gradle 8.7، APK دیباگ را می‌سازد و به عنوان Artifact تحویل می‌دهد.

خروجی:

`app/build/outputs/apk/debug/app-debug.apk`

## محل داشبورد

`app/src/main/assets/index.html`

ذخیره‌سازی `localStorage` داشبورد روی همان دستگاه باقی می‌ماند.
